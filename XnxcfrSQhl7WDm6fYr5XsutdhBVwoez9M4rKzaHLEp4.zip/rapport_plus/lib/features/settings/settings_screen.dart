import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/config/app_config.dart';
import '../../core/widgets/support_dialog.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _reminderEnabled = true;
  TimeOfDay _reminderTime = const TimeOfDay(hour: 18, minute: 0);
  String _selectedDays = 'Lun-Ven';
  bool _darkMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceLight,
      appBar: AppBar(title: const Text('Profil & Paramètres')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.borderLight)),
              child: Row(children: [
                Container(width: 56, height: 56, decoration: BoxDecoration(color: AppTheme.navy, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.person, color: Colors.white, size: 28)),
                const SizedBox(width: 14),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Ahmed Ben Ali', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)), Text('ISET Sousse • Génie Logiciel', style: TextStyle(fontSize: 12, color: AppTheme.textMuted)), Text('Stage: TELNET Holding', style: TextStyle(fontSize: 12, color: AppTheme.blueSoft))])),
                IconButton(icon: const Icon(Icons.edit_outlined, size: 20), onPressed: () => _editProfile()),
              ]),
            ),
            const SizedBox(height: 16),

            // Internships
            _Section(title: 'Mes stages', icon: Icons.work_outline, child: Column(children: [
              _InternshipTile(title: 'Stage PFE - Génie Logiciel', company: 'TELNET Holding', period: '15 sept - 15 nov 2026', active: true),
              _InternshipTile(title: 'Stage Technicien', company: 'STEG Sousse', period: '10 juin - 10 août 2025', active: false),
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.add, size: 18), label: const Text('Nouveau stage'), style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 44))),
            ])),
            const SizedBox(height: 12),

            // Notifications
            _Section(title: 'Rappels journaliers', icon: Icons.notifications_outlined, child: Column(children: [
              SwitchListTile(
                title: const Text('Rappel quotidien', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                subtitle: Text(_reminderEnabled ? 'Tous les jours à ${_reminderTime.format(context)}' : 'Désactivé', style: const TextStyle(fontSize: 12)),
                value: _reminderEnabled,
                onChanged: (v) => setState(() => _reminderEnabled = v),
                contentPadding: EdgeInsets.zero,
              ),
              if (_reminderEnabled) ...[
                ListTile(
                  leading: const Icon(Icons.access_time, size: 20, color: AppTheme.navy),
                  title: const Text('Heure du rappel', style: TextStyle(fontSize: 13)),
                  subtitle: Text(_reminderTime.format(context), style: const TextStyle(fontWeight: FontWeight.w600)),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  contentPadding: EdgeInsets.zero,
                  onTap: () async {
                    final picked = await showTimePicker(context: context, initialTime: _reminderTime);
                    if (picked != null) setState(() => _reminderTime = picked);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.calendar_today, size: 18, color: AppTheme.navy),
                  title: const Text('Jours de travail', style: TextStyle(fontSize: 13)),
                  subtitle: Text(_selectedDays, style: const TextStyle(fontWeight: FontWeight.w600)),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  contentPadding: EdgeInsets.zero,
                  onTap: () {},
                ),
                const SizedBox(height: 4),
                OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.notifications_active, size: 16), label: const Text('Tester la notification'), style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 40))),
              ],
            ])),
            const SizedBox(height: 12),

            // Google Drive
            _Section(title: 'Sauvegarde Google Drive', icon: Icons.cloud_outlined, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(10)), child: const Row(children: [Icon(Icons.info_outline, size: 16, color: AppTheme.blueSoft), SizedBox(width: 8), Expanded(child: Text('Optionnel • Données chiffrées • Vous gardez le contrôle', style: TextStyle(fontSize: 12)))])),
              const SizedBox(height: 10),
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFF0FDF4), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF86EFAC))), child: const Row(children: [Icon(Icons.check_circle, size: 14, color: AppTheme.success), SizedBox(width: 4), Text('Non connecté', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600))])),
                const Spacer(),
                ElevatedButton(onPressed: () {}, style: ElevatedButton.styleFrom(minimumSize: const Size(0, 36), padding: const EdgeInsets.symmetric(horizontal: 16)), child: const Text('Connecter', style: TextStyle(fontSize: 13))),
              ]),
              const SizedBox(height: 8),
              Text('Permissions: drive.file + drive.appdata uniquement', style: TextStyle(fontSize: 11, color: Colors.grey[600])),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.backup, size: 16), label: const Text('Sauvegarder', style: TextStyle(fontSize: 13)))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.restore, size: 16), label: const Text('Restaurer', style: TextStyle(fontSize: 13)))),
              ]),
            ])),
            const SizedBox(height: 12),

            // AI Model
            _Section(title: 'Intelligence artificielle locale', icon: Icons.smart_toy_outlined, child: Column(children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFFFFFBEB), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFFDE68A))),
                child: const Row(children: [Icon(Icons.warning_amber, size: 18, color: AppTheme.warning), SizedBox(width: 8), Expanded(child: Text('Aucun modèle installé. L\'app fonctionne sans IA. Installez un modèle pour la correction automatique.', style: TextStyle(fontSize: 12)))]),
              ),
              const SizedBox(height: 10),
              ListTile(
                leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: AppTheme.navy.withOpacity(0.08), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.memory, color: AppTheme.navy, size: 20)),
                title: const Text('Gérer les modèles IA', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                subtitle: const Text('Qwen2.5 3B • TinyLlama • Whisper', style: TextStyle(fontSize: 12)),
                trailing: const Icon(Icons.chevron_right),
                contentPadding: EdgeInsets.zero,
                onTap: () => context.go('/ai/models'),
              ),
            ])),
            const SizedBox(height: 12),

            // Appearance
            _Section(title: 'Apparence', icon: Icons.palette_outlined, child: Column(children: [
              SwitchListTile(title: const Text('Mode sombre', style: TextStyle(fontSize: 14)), value: _darkMode, onChanged: (v) => setState(() => _darkMode = v), contentPadding: EdgeInsets.zero),
              ListTile(leading: const Icon(Icons.language, size: 20), title: const Text('Langue de l\'interface', style: TextStyle(fontSize: 14)), subtitle: const Text('Français', style: TextStyle(fontSize: 12)), trailing: const Icon(Icons.chevron_right, size: 18), contentPadding: EdgeInsets.zero, onTap: () {}),
            ])),
            const SizedBox(height: 12),

            // Help & Support
            _Section(title: 'Aide & Support', icon: Icons.help_outline, child: Column(children: [
              ListTile(
                leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: AppTheme.navy.withOpacity(0.08), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.support_agent, color: AppTheme.navy, size: 20)),
                title: const Text('Contacter l\'administrateur', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                subtitle: Text('${AppConfig.adminName} • ${AppConfig.adminPhone}', style: const TextStyle(fontSize: 12)),
                trailing: const Icon(Icons.chevron_right),
                contentPadding: EdgeInsets.zero,
                onTap: () => SupportDialog.show(context),
              ),
              const Divider(height: 1),
              ListTile(leading: const Icon(Icons.menu_book_outlined, size: 20), title: const Text('Guide d\'utilisation', style: TextStyle(fontSize: 14)), trailing: const Icon(Icons.chevron_right, size: 18), contentPadding: EdgeInsets.zero, onTap: () {}),
              ListTile(leading: const Icon(Icons.privacy_tip_outlined, size: 20), title: const Text('Confidentialité', style: TextStyle(fontSize: 14)), subtitle: const Text('Données locales • Aucun envoi automatique', style: TextStyle(fontSize: 11)), contentPadding: EdgeInsets.zero, onTap: () {}),
            ])),
            const SizedBox(height: 12),

            // Danger zone
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.borderLight)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Zone sensible', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: AppTheme.error)),
                const SizedBox(height: 8),
                OutlinedButton.icon(onPressed: () => _confirmAction('Exporter toutes les données', 'Vos données seront exportées en JSON.'), icon: const Icon(Icons.download, size: 16), label: const Text('Exporter mes données'), style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 40))),
                const SizedBox(height: 8),
                OutlinedButton.icon(onPressed: () => _confirmAction('Supprimer toutes les données', 'Cette action est irréversible !', isDestructive: true), icon: const Icon(Icons.delete_forever, size: 16, color: AppTheme.error), label: const Text('Supprimer toutes les données', style: TextStyle(color: AppTheme.error)), style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 40), side: const BorderSide(color: AppTheme.error))),
              ]),
            ),
            const SizedBox(height: 16),
            Center(child: Text('Rapport+ v${AppConfig.appVersion} • Fait avec ❤️ en Tunisie', style: TextStyle(fontSize: 11, color: Colors.grey[500]))),
            Center(child: Text('Toutes les fonctionnalités principales fonctionnent hors-ligne', style: TextStyle(fontSize: 11, color: Colors.grey[400]))),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _editProfile() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 16, right: 16, top: 16),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 16),
            const Text('Modifier le profil', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 12),
            const TextField(decoration: InputDecoration(labelText: 'Nom complet')),
            const SizedBox(height: 10),
            const TextField(decoration: InputDecoration(labelText: 'Établissement')),
            const SizedBox(height: 10),
            const TextField(decoration: InputDecoration(labelText: 'Filière')),
            const SizedBox(height: 10),
            const TextField(decoration: InputDecoration(labelText: 'Entreprise')),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('Enregistrer')),
            const SizedBox(height: 16),
          ]),
        ),
      ),
    );
  }

  void _confirmAction(String title, String desc, {bool isDestructive = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title, style: TextStyle(color: isDestructive ? AppTheme.error : null)),
        content: Text(desc),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')), ElevatedButton(onPressed: () => Navigator.pop(context), style: isDestructive ? ElevatedButton.styleFrom(backgroundColor: AppTheme.error) : null, child: Text(isDestructive ? 'Supprimer' : 'Confirmer'))],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;
  const _Section({required this.title, required this.icon, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.borderLight)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Icon(icon, size: 18, color: AppTheme.navy), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppTheme.navy))]),
          const SizedBox(height: 12),
          child,
        ]),
      );
}

class _InternshipTile extends StatelessWidget {
  final String title;
  final String company;
  final String period;
  final bool active;
  const _InternshipTile({required this.title, required this.company, required this.period, required this.active});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: active ? AppTheme.navy.withOpacity(0.06) : AppTheme.surfaceLight, borderRadius: BorderRadius.circular(10), border: Border.all(color: active ? AppTheme.navy.withOpacity(0.15) : AppTheme.borderLight)),
        child: Row(children: [
          Container(width: 8, height: 40, decoration: BoxDecoration(color: active ? AppTheme.success : Colors.grey[400], borderRadius: BorderRadius.circular(4))),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)), Text(company, style: const TextStyle(fontSize: 12, color: AppTheme.textMuted)), Text(period, style: const TextStyle(fontSize: 11, color: AppTheme.textMuted))])),
          if (active) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: AppTheme.success, borderRadius: BorderRadius.circular(20)), child: const Text('Actif', style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w600))),
        ]),
      );
}
